#include "stb-master/stb_image.h"
#include <iostream>
#include <GL/gl.h>
#define STB_IMAGE_IMPLEMENTATION
#include "stb-master/stb_image.h"
GLuint texture_Load(char *filename, int cnt=3)
{
    int width, height;
    unsigned char *image = stbi_load(filename, &width, &height, &cnt, 0);
    if (image == NULL) {
        printf("Error in loading the image: %s\n", stbi_failure_reason());
        exit(1);
    }
    GLuint textureID;
    glGenTextures(1, &textureID);
    glBindTexture(GL_TEXTURE_2D, textureID);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, width, height, 0, cnt == 4 ? GL_RGBA : GL_RGB, GL_UNSIGNED_BYTE, image);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    stbi_image_free(image);
    return textureID;
}
void show_Texture(GLuint textureID, RECT texsize){
     float centerX = texsize.right / 2.0f;
            float posY = 0.0f;
            float spriteWidth = texsize.right-texsize.left; // ширина текстуры
            float spriteHeight = -texsize.top+texsize.bottom; // высота текстуры
   float sprite1PosX = centerX - (spriteWidth / 2);
                        float sprite1PosY = posY;

                        glEnable(GL_TEXTURE_2D);
                        glBindTexture(GL_TEXTURE_2D, textureID);
                        glColor3f(1,1,1);
                        glPushMatrix();
                        glBegin(GL_QUADS);
                        glTexCoord2f(0.0f, 0.0f); glVertex2f(sprite1PosX, sprite1PosY);
                        glTexCoord2f(1.0f, 0.0f); glVertex2f(sprite1PosX + spriteWidth, sprite1PosY);
                        glTexCoord2f(1.0f, 1.0f); glVertex2f(sprite1PosX + spriteWidth, sprite1PosY + spriteHeight);
                        glTexCoord2f(0.0f, 1.0f); glVertex2f(sprite1PosX, sprite1PosY + spriteHeight);
                        glEnd();
                        glDisable(GL_TEXTURE_2D);
                        glPopMatrix();
}
void UpdateAnimationFrame(int &currentFrame,int totalFrames) {
    currentFrame = (currentFrame + 1) % totalFrames;
}

void RenderSpriteAnimation(GLuint texture, float posX, float posY, float width, float height, float scale, int currentFrame) {
    float frameWidth = 1.0f / 8;
    float texLeft = currentFrame * frameWidth;
    float texRight = texLeft + frameWidth;

    float scaledWidth = width * scale;
    float scaledHeight = height * scale;

    glEnable(GL_TEXTURE_2D);
    glBindTexture(GL_TEXTURE_2D, texture);

    glColor3f(1,1,1);
    glBegin(GL_QUADS);
        glTexCoord2f(texLeft, 0.0f); glVertex2f(posX, posY);
        glTexCoord2f(texRight, 0.0f); glVertex2f(posX + scaledWidth, posY);
        glTexCoord2f(texRight, 1.0f); glVertex2f(posX + scaledWidth, posY + scaledHeight);
        glTexCoord2f(texLeft, 1.0f); glVertex2f(posX, posY + scaledHeight);
    glEnd();

    glDisable(GL_TEXTURE_2D);

}



void mapRender(std::string TileMap[8]){
    const float tsize = 100;
    const int H = 8;
    const int W = 8;
    for (int i = 0; i < H; i++){
        for (int j = 0; j < W; j++){
            if (TileMap[i][j] == '_'){
                GLfloat x = j * tsize;
                GLfloat y = i * tsize;
                glBegin(GL_QUADS);
                glColor3f(0.576f + j*0.03f, 0.698f + i*0.03f, 0.949f);
                glVertex2f(x, y);
                glVertex2f(x + tsize, y);
                glVertex2f(x + tsize, y + tsize);
                glVertex2f(x, y + tsize);
                glEnd();
            }
            if (TileMap[i][j] == 'x'){
                GLfloat x = j * tsize;
                GLfloat y = i * tsize;
                glBegin(GL_QUADS);
                glColor3f(0.276f + j*0.2f, 0.198f + i*0.03f, 0.549f);
                glVertex2f(x, y);
                glVertex2f(x + tsize, y);
                glVertex2f(x + tsize, y + tsize);
                glVertex2f(x, y + tsize);
                glEnd();
            }
        }
    }
}
