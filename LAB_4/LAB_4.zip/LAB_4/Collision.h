#ifndef COLLISION_H_INCLUDED
#define COLLISION_H_INCLUDED
#include <map>
#include <stdio.h>
void check_Collision(std::map <std::string, int> *character,RECT rect,std::string TileMap[8]);
#endif // COLLISION_H_INCLUDED



