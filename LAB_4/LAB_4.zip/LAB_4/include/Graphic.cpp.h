#ifndef GRAPHIC_CPP_H
#define GRAPHIC_CPP_H


class Graphic.cpp
{
    public:
        Graphic.cpp();
        virtual ~Graphic.cpp();

    protected:

    private:
};

#endif // GRAPHIC_CPP_H
