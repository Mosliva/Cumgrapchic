#include <windows.h>
#include <gl/gl.h>
#include <stdio.h>
#include <stdlib.h>
#include <malloc.h>
#include <stdbool.h>
#include "stb-master/stb_easy_font.h"
#include "menu.h"
#include "Graphic.h"
#include "Collision.h"
#include <iostream>
#define nameLen 20
#include <map>


LRESULT CALLBACK WindowProc(HWND, UINT, WPARAM, LPARAM);
void EnableOpenGL(HWND hwnd, HDC*, HGLRC*);
void DisableOpenGL(HWND, HDC, HGLRC);


  std::map <std::string, int> character =
{
    { "x", 500 },
    { "y", 500 }
};
;
std::string TileMap[8] = {
    "________",
    "        ",
    "     __ ",
    "_       ",
    "        ",
    "___     ",
    "_____  _",
    "________"
};


int currentFrame=0;
int currentFrame_stay=0;
int currentFrame_jump=0;
int totalFrames=8;
extern std::string gameState;

int WINAPI WinMain(HINSTANCE hInstance,HINSTANCE hPrevInstance,LPSTR lpCmdLine,int nCmdShow)
{
    WNDCLASSEX wcex;
    HWND hwnd;
    HDC hDC;
    HGLRC hRC;
    MSG msg;
    BOOL bQuit = FALSE;
    float theta = 0.0f;

    /* register window class */
    wcex.cbSize = sizeof(WNDCLASSEX);
    wcex.style = CS_OWNDC;
    wcex.lpfnWndProc = WindowProc;
    wcex.cbClsExtra = 0;
    wcex.cbWndExtra = 0;
    wcex.hInstance = hInstance;
    wcex.hIcon = LoadIcon(NULL, IDI_APPLICATION);
    wcex.hCursor = LoadCursor(NULL, IDC_ARROW);
    wcex.hbrBackground = (HBRUSH)GetStockObject(BLACK_BRUSH);
    wcex.lpszMenuName = NULL;
    wcex.lpszClassName = "GLSample";
    wcex.hIconSm = LoadIcon(NULL, IDI_APPLICATION);;


    if (!RegisterClassEx(&wcex))
        return 0;

    /* create main window */
    hwnd = CreateWindowEx(0,"GLSample","OpenGL Sample",WS_OVERLAPPEDWINDOW,CW_USEDEFAULT,CW_USEDEFAULT,800,800,NULL,NULL,hInstance,NULL);

    ShowWindow(hwnd, nCmdShow);

    /* enable OpenGL for the window */
    EnableOpenGL(hwnd, &hDC, &hRC);
    RECT rect;
    GetClientRect(hwnd,&rect);
    glOrtho(rect.left,rect.right/2,rect.bottom,rect.top,1,-1);
    GLuint bg=texture_Load("background.jpg");
    GLuint r_run=texture_Load("r_run.png",4);
    GLuint l_run=texture_Load("l_run.png",4);
    GLuint stay=texture_Load("stay.png",4);
    GLuint jump=texture_Load("jump.png",4);
            float fontColor[3] = {0.961f,0.906f,0.067f};
            float color[3] = {0.321f,0.456f,0.245f};
            Menu_AddButton("Start", 5.0f, 5.0f, 200.0f, 200.0f, 2.0f,color,fontColor);
            Menu_AddButton("Exit", 505.0f, 5.0f, 200.0f, 200.0f, 2.0f,color,fontColor);


    /* program main loop */
    while (!bQuit)
    {
        /* check for messages */
        if (PeekMessage(&msg, NULL, 0, 0, PM_REMOVE))
        {
            /* handle or dispatch messages */
            if (msg.message == WM_QUIT)
            {
                bQuit = TRUE;
            }
            else
            {
                TranslateMessage(&msg);
                DispatchMessage(&msg);
            }
        }
        else
        {
            /* OpenGL animation code goes here */


            /* OpenGL animation code goes here */

            glClearColor(0.0f, 0.0f, 0.0f, 0.0f);
            glClear(GL_COLOR_BUFFER_BIT);
            show_Texture(bg,rect);
            Menu_ShowMenu();

            if(gameState=="game"){
                    mapRender(TileMap);
            if(character["right_running"]){
                    UpdateAnimationFrame(currentFrame,totalFrames);
                    RenderSpriteAnimation(r_run,character["x"],character["y"], 640.0f / 8.0f, 80.0f, 1.0f,currentFrame);
                    character["x"]+=10;
                    check_Collision(&character,rect,TileMap);
                    }
            else if(character["left_running"]){
                UpdateAnimationFrame(currentFrame,totalFrames);
                RenderSpriteAnimation(l_run,character["x"],character["y"], 640.0f / 8.0f, 80.0f, 1.0f,currentFrame);
                character["x"]-=10;
                check_Collision(&character,rect,TileMap);
            }
            else if (character["up"])
            {
                  UpdateAnimationFrame(currentFrame_jump,totalFrames);
                  RenderSpriteAnimation(jump,character["x"],character["y"], 640.0f / 8.0f, 80.0f, 1.0f,currentFrame_jump);
                    if(character["ay"]>0){
                        character["y"]-=character["ay"];
                        character["ay"]-=3;}
                  if(character["y"]==600)
                    character["up"]=0;
                    check_Collision(&character,rect,TileMap);
            }else{
             UpdateAnimationFrame(currentFrame_stay,totalFrames);
                  RenderSpriteAnimation(stay,character["x"],character["y"], 640.0f / 8.0f, 80.0f, 1.0f,currentFrame_stay);
            }

            character["y"]+=10;
            check_Collision(&character,rect,TileMap);
            }
            glPushMatrix();
            glPopMatrix();

            SwapBuffers(hDC);
            Sleep (24);
        }
    }

    DisableOpenGL(hwnd, hDC, hRC);

    DestroyWindow(hwnd);

    return msg.wParam;
}





LRESULT CALLBACK WindowProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{

    switch (uMsg)
    {
        case WM_CLOSE:
            PostQuitMessage(0);
        break;
        case WM_DESTROY:
            return 0;
        case WM_LBUTTONDOWN:
            MouseDown();
        case WM_MOUSEMOVE:
            Menu_MouseMove(LOWORD(lParam),HIWORD(lParam));

        case WM_KEYDOWN:
        {

            switch (wParam)
            {
                case VK_ESCAPE:
                    PostQuitMessage(0);
                break;
            }
             if(wParam==VK_UP){
                    if(character["up"]==0){
                        character["up"]=1;
                        character["ay"]=40;
                        }
            }
            if(wParam==VK_RIGHT)
                character["right_running"]=1;

             if(wParam==VK_LEFT)
                character["left_running"]=1;


        }
        break;

        default:{
            character["right_running"]=0;
            character["left_running"]=0;
            return DefWindowProc(hwnd, uMsg, wParam, lParam);}
    }

    return 0;
}

void EnableOpenGL(HWND hwnd, HDC* hDC, HGLRC* hRC)
{
    PIXELFORMATDESCRIPTOR pfd;

    int iFormat;

    /* get the device context (DC) */
    *hDC = GetDC(hwnd);

    /* set the pixel format for the DC */
    ZeroMemory(&pfd, sizeof(pfd));

    pfd.nSize = sizeof(pfd);
    pfd.nVersion = 1;
    pfd.dwFlags = PFD_DRAW_TO_WINDOW |
                  PFD_SUPPORT_OPENGL | PFD_DOUBLEBUFFER;
    pfd.iPixelType = PFD_TYPE_RGBA;
    pfd.cColorBits = 24;
    pfd.cDepthBits = 16;
    pfd.iLayerType = PFD_MAIN_PLANE;

    iFormat = ChoosePixelFormat(*hDC, &pfd);

    SetPixelFormat(*hDC, iFormat, &pfd);

    /* create and enable the render context (RC) */
    *hRC = wglCreateContext(*hDC);

    wglMakeCurrent(*hDC, *hRC);
}

void DisableOpenGL (HWND hwnd, HDC hDC, HGLRC hRC)
{
    wglMakeCurrent(NULL, NULL);
    wglDeleteContext(hRC);
    ReleaseDC(hwnd, hDC);
}
