#include <map>
#include <iostream>
#include <GL/gl.h>
#include "Menu.h"
void check_Collision(std::map <std::string, int> *character,RECT rect,std::string TileMap[8]){
    if ((*character)["y"]<0)
            (*character)["y"]=0;
    if ((*character)["x"]>rect.right-50)
            (*character)["x"]=rect.right-50;
    if ((*character)["x"]<0)
            (*character)["x"]=0;


    const int tileSize=100;
    int tileX = (*character)["x"] / tileSize;
    int tileY = (*character)["y"] / tileSize;
    if(TileMap[(*character)["y"]/ tileSize][(*character)["x"] / tileSize]=='x'){

        State_Changer("win");
    }
     if (TileMap[(*character)["y"]/ tileSize][((*character)["x"]+30) / tileSize]=='_'&&(*character)["y"]+40<(tileY)*tileSize+70)
    {
                   //std::cout<<"up"<<std::endl;
    (*character)["y"]=(tileY)*100+70;
        return;
    }
    if (TileMap[((*character)["y"]+69) / tileSize][((*character)["x"])/ tileSize]=='_'&&(*character)["x"]<(tileX+0.75)*tileSize)
    {
        //std::cout<<"left"<<std::endl;
    (*character)["x"]=(tileX)*100+80;
        return;
    }




    if (TileMap[((*character)["y"]+69) / tileSize][((*character)["x"]+40)/ tileSize]=='_'&&(*character)["x"]>tileX*tileSize)
    {

               //std::cout<<"right"<<std::endl;
    (*character)["x"]=(tileX)*100+40;
        return;
    }


     if (TileMap[tileY+1][((*character)["x"]+40)/tileSize]=='_'&&(*character)["y"]>(tileY)*tileSize)
    {
           //std::cout<<"down"<<std::endl;
    (*character)["y"]=(tileY)*100+20;
        (*character)["up"]=0;
        return;
    }



}
