#include <map>
#include <iostream>
#include <GL/gl.h>
void check_Collision(std::map <std::string, int> *character,RECT rect){
    if ((*character)["y"]<0)
            (*character)["y"]=0;
    if ((*character)["x"]>rect.right-50)
            (*character)["x"]=rect.right-50;
    if ((*character)["x"]<0)
            (*character)["x"]=0;

const std::string TileMap[8] = {
    "________",
    "__     _",
    "_   ____",
    "________",
    "   __   ",
    "  ______",
    " _______",
    "________"
};
    const int tileSize=100;
    int tileX = (*character)["x"] / tileSize;
    int tileY = (*character)["y"] / tileSize;
    if (TileMap[tileY][((*character)["x"]+40)/ tileSize]=='_'&&(*character)["x"]>tileX*tileSize)
    {
    (*character)["x"]=(tileX)*100+40;
        return;
    }







    if (TileMap[((*character)["y"]-80)/ tileSize][tileX]&&(*character)["y"]<(tileY-1)*tileSize)
    {
std::cout<<tileY<<" "<<tileX<<" "<<(*character)["x"]<<" "<<(*character)["y"]<<std::endl;
    (*character)["y"]=(tileY)*100+40;
        return;
    }
     if (TileMap[tileY+1][tileX]=='_'&&(*character)["y"]<(tileY+1)*tileSize)
    {
        //std::cout<<tileY<<" "<<tileX<<" "<<(*character)["x"]<<" "<<(*character)["y"]<<std::endl;
    (*character)["y"]=(tileY)*100+20;
        (*character)["up"]=0;
        return;
    }



}
