#include "Graphic.cpp.h"

Graphic.cpp::Graphic.cpp()
{
    //ctor
}

Graphic.cpp::~Graphic.cpp()
{
    //dtor
}
